package com.ollierstore.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.util.Base64

class MainActivity : android.app.Activity() {
    private lateinit var web: WebView
    private val home = "https://ollierstore.rf.gd/?i=1"

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.databaseEnabled = true
        web.settings.allowFileAccess = false
        web.settings.allowContentAccess = true
        web.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)

        web.addJavascriptInterface(DownloadBridge(this), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectDownloadBridge(view)
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            // Important: JavaScript prompt() used by inventory cards must be shown in the APK.
            override fun onJsPrompt(view: WebView, url: String, message: String, defaultValue: String?, result: android.webkit.JsPromptResult): Boolean {
                return super.onJsPrompt(view, url, message, defaultValue, result)
            }
            override fun onJsAlert(view: WebView, url: String, message: String, result: android.webkit.JsResult): Boolean {
                return super.onJsAlert(view, url, message, result)
            }
            override fun onJsConfirm(view: WebView, url: String, message: String, result: android.webkit.JsResult): Boolean {
                return super.onJsConfirm(view, url, message, result)
            }
        }
        web.setDownloadListener(DownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                val request = DownloadManager.Request(Uri.parse(url))
                request.setMimeType(mimeType ?: "application/octet-stream")
                request.addRequestHeader("User-Agent", userAgent)
                val cookies = CookieManager.getInstance().getCookie(url)
                if (!cookies.isNullOrBlank()) request.addRequestHeader("Cookie", cookies)
                request.setTitle(fileNameFromDisposition(contentDisposition, mimeType))
                request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileNameFromDisposition(contentDisposition, mimeType))
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                Toast.makeText(this, "Téléchargement lancé", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(this, "Téléchargement impossible", Toast.LENGTH_SHORT).show() }
        })
        web.loadUrl(home)
    }

    private fun injectDownloadBridge(view: WebView) {
        val js = """
        (function(){
          if(window.__ollierNativeBridge)return; window.__ollierNativeBridge=true;
          document.addEventListener('click',function(ev){
            var a=ev.target&&ev.target.closest?ev.target.closest('a[download]'):null;
            if(!a)return; var href=a.href||''; var name=a.download||'download';
            if(href.indexOf('blob:')===0){
              ev.preventDefault(); ev.stopPropagation();
              fetch(href).then(function(r){return r.blob()}).then(function(b){
                var rd=new FileReader(); rd.onloadend=function(){
                  var s=String(rd.result||''); var comma=s.indexOf(',');
                  Android.saveBase64(name,b.type||'application/octet-stream',comma>=0?s.substring(comma+1):s);
                }; rd.readAsDataURL(b);
              }).catch(function(){Android.error('blob')});
            }
          },true);
        })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun fileNameFromDisposition(cd: String?, mime: String?): String {
        val match = Regex("filename[^;=]*=\\s*\\\"?([^\\\";]+)").find(cd ?: "")
        if (match != null) return match.groupValues[1]
        val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime ?: "") ?: "bin"
        return "OllierStore_${System.currentTimeMillis()}.$ext"
    }

    override fun onBackPressed() { if (web.canGoBack()) web.goBack() else super.onBackPressed() }

    class DownloadBridge(private val context: Context) {
        @JavascriptInterface fun saveBase64(name: String, mime: String, data: String) {
            try {
                val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "OllierStore_download" }
                val bytes = Base64.getDecoder().decode(data)
                val resolver = context.contentResolver
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safe)
                    put(MediaStore.Downloads.MIME_TYPE, mime.ifBlank { "application/octet-stream" })
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: throw Exception("insert")
                resolver.openOutputStream(uri).use { it!!.write(bytes) }
                if (Build.VERSION.SDK_INT >= 29) {
                    values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0); resolver.update(uri, values, null, null)
                }
                android.os.Handler(context.mainLooper).post { Toast.makeText(context, "Fichier enregistré dans Téléchargements", Toast.LENGTH_LONG).show() }
            } catch (e: Exception) { error("save") }
        }
        @JavascriptInterface fun error(type: String) { android.os.Handler(context.mainLooper).post { Toast.makeText(context, "Téléchargement impossible", Toast.LENGTH_SHORT).show() } }
    }
}
